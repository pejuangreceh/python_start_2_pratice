from pygame import *

#create game window

#set scene background

#creat 2 sprites and place them on the scene

#handle "click on the "Close the window"" event 